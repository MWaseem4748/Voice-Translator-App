import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:google_mlkit_translation/google_mlkit_translation.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

enum TranslationMode { listenMode, speakMode }
enum AppState { idle, listening, translating, speaking, error }
enum Direction { japaneseToEnglish, englishToJapanese }

class TranslationEntry {
  final String original;
  final String translated;
  final Direction direction;
  final DateTime timestamp;

  TranslationEntry({
    required this.original,
    required this.translated,
    required this.direction,
    required this.timestamp,
  });
}

class TranslatorService extends ChangeNotifier {
  // Core services
  final SpeechToText _stt = SpeechToText();
  final FlutterTts _tts = FlutterTts();

  // ML Kit translators (both directions pre-loaded)
  OnDeviceTranslator? _jaToEnTranslator;
  OnDeviceTranslator? _enToJaTranslator;
  final _modelManager = OnDeviceTranslatorModelManager();

  // State
  AppState _appState = AppState.idle;
  TranslationMode _mode = TranslationMode.listenMode;
  Direction _direction = Direction.japaneseToEnglish;

  String _liveText = '';           // What STT is hearing right now
  String _translatedText = '';     // Latest translation
  String _statusMessage = 'Ready';
  bool _isInitialized = false;
  bool _modelsDownloaded = false;
  double _modelDownloadProgress = 0.0;

  // History
  final List<TranslationEntry> _history = [];

  // Getters
  AppState get appState => _appState;
  TranslationMode get mode => _mode;
  Direction get direction => _direction;
  String get liveText => _liveText;
  String get translatedText => _translatedText;
  String get statusMessage => _statusMessage;
  bool get isInitialized => _isInitialized;
  bool get modelsDownloaded => _modelsDownloaded;
  double get modelDownloadProgress => _modelDownloadProgress;
  List<TranslationEntry> get history => List.unmodifiable(_history);
  bool get isListening => _appState == AppState.listening;
  bool get isSpeaking => _appState == AppState.speaking;
  bool get isTranslating => _appState == AppState.translating;

  // Derived: what language is the microphone listening for?
  String get sttLocale => _direction == Direction.japaneseToEnglish
      ? 'ja_JP'
      : 'en_US';

  String get inputLanguageLabel =>
      _direction == Direction.japaneseToEnglish ? '日本語' : 'English';

  String get outputLanguageLabel =>
      _direction == Direction.japaneseToEnglish ? 'English' : '日本語';

  // ─── INIT ────────────────────────────────────────────────────────────────

  Future<void> initialize() async {
    if (_isInitialized) return;
    _setStatus('Initializing...');

    // 1. Microphone permission
    final micStatus = await Permission.microphone.request();
    if (!micStatus.isGranted) {
      _setAppState(AppState.error);
      _setStatus('Microphone permission denied. Go to Settings → Apps → voice_translator → Permissions.');
      return;
    }

    // 2. Init STT
    final sttAvailable = await _stt.initialize(
      onError: (error) {
        debugPrint('STT error: $error');
        _setStatus('Mic error: ${error.errorMsg}');
        _setAppState(AppState.idle);
      },
      onStatus: (status) {
        debugPrint('STT status: $status');
        if (status == 'done' || status == 'notListening') {
          if (_appState == AppState.listening) {
            _setAppState(AppState.idle);
          }
        }
      },
    );

    if (!sttAvailable) {
      _setAppState(AppState.error);
      _setStatus('Speech recognition not available on this device.');
      return;
    }

    // 3. Init TTS
    await _tts.setSharedInstance(true);
    await _tts.awaitSpeakCompletion(true);
    await _tts.setSpeechRate(0.9);
    await _tts.setVolume(1.0);
    await _tts.setPitch(1.0);

    _tts.setCompletionHandler(() {
      if (_appState == AppState.speaking) {
        _setAppState(AppState.idle);
        _setStatus('Ready');
      }
    });

    // 4. Download / verify ML Kit language models
    await _ensureModels();

    // 5. Create translators
    _jaToEnTranslator = OnDeviceTranslator(
      sourceLanguage: TranslateLanguage.japanese,
      targetLanguage: TranslateLanguage.english,
    );
    _enToJaTranslator = OnDeviceTranslator(
      sourceLanguage: TranslateLanguage.english,
      targetLanguage: TranslateLanguage.japanese,
    );

    // 6. Load saved preferences
    final prefs = await SharedPreferences.getInstance();
    final savedDirection = prefs.getInt('direction') ?? 0;
    _direction = Direction.values[savedDirection];

    _isInitialized = true;
    _setAppState(AppState.idle);
    _setStatus('Ready — tap Listen or hold Speak');
    notifyListeners();
  }

  Future<void> _ensureModels() async {
    _setStatus('Checking language models...');
    _modelDownloadProgress = 0.0;
    notifyListeners();

    final jaDownloaded = await _modelManager.isModelDownloaded(TranslateLanguage.japanese.bcpCode);
    final enDownloaded = await _modelManager.isModelDownloaded(TranslateLanguage.english.bcpCode);

    if (!jaDownloaded || !enDownloaded) {
      _setStatus('Downloading language models (once only, ~30MB)...');

      if (!jaDownloaded) {
        _setStatus('Downloading Japanese model...');
        await _modelManager.downloadModel(TranslateLanguage.japanese.bcpCode);
        _modelDownloadProgress = 0.5;
        notifyListeners();
      }

      if (!enDownloaded) {
        _setStatus('Downloading English model...');
        await _modelManager.downloadModel(TranslateLanguage.english.bcpCode);
        _modelDownloadProgress = 1.0;
        notifyListeners();
      }
    }

    _modelsDownloaded = true;
    _modelDownloadProgress = 1.0;
    notifyListeners();
  }

  // ─── LISTEN MODE (hear the other person, translate to your language) ─────

  Future<void> startListening() async {
    if (!_isInitialized || _appState == AppState.speaking) return;

    _liveText = '';
    _translatedText = '';
    _setMode(TranslationMode.listenMode);
    _setAppState(AppState.listening);
    _setStatus('Listening in ${inputLanguageLabel}...');

    await WakelockPlus.enable();

    await _stt.listen(
      localeId: sttLocale,
      listenMode: ListenMode.dictation,
      pauseFor: const Duration(seconds: 2),
      listenFor: const Duration(seconds: 60),
      partialResults: true,
      onResult: _onSttResult,
    );

    notifyListeners();
  }

  void _onSttResult(SpeechRecognitionResult result) {
    _liveText = result.recognizedWords;
    notifyListeners();

    // When final result arrives, translate it
    if (result.finalResult && _liveText.trim().isNotEmpty) {
      _translateAndSpeak(_liveText, speak: false);
    }
  }

  Future<void> stopListening() async {
    await _stt.stop();
    _setAppState(AppState.idle);
    _setStatus('Ready');
    await WakelockPlus.disable();
    notifyListeners();
  }

  // ─── SPEAK MODE (your voice, translate to their language) ─────────────────

  Future<void> startSpeaking() async {
    if (!_isInitialized || _appState == AppState.speaking) return;

    _liveText = '';
    _translatedText = '';
    _setMode(TranslationMode.speakMode);
    _setAppState(AppState.listening);
    _setStatus('Speak in ${outputLanguageLabel}... (release to translate)');

    await WakelockPlus.enable();

    // In speak mode, we capture YOUR voice in the output language
    // Then translate it and play it via TTS for the other person
    final speakLocale = _direction == Direction.japaneseToEnglish
        ? 'en_US'
        : 'ja_JP';

    await _stt.listen(
      localeId: speakLocale,
      listenMode: ListenMode.dictation,
      pauseFor: const Duration(seconds: 2),
      listenFor: const Duration(seconds: 30),
      partialResults: true,
      onResult: (result) {
        _liveText = result.recognizedWords;
        notifyListeners();
        if (result.finalResult && _liveText.trim().isNotEmpty) {
          _translateAndSpeak(_liveText, speak: true);
        }
      },
    );

    notifyListeners();
  }

  Future<void> stopSpeaking() async {
    await _stt.stop();
    // Don't idle here — let the STT finalResult trigger translation
    _setStatus('Translating...');
    notifyListeners();
  }

  // ─── CORE: Translate + optionally speak ──────────────────────────────────

  Future<void> _translateAndSpeak(String text, {required bool speak}) async {
    if (text.trim().isEmpty) return;

    _setAppState(AppState.translating);
    _setStatus('Translating...');

    try {
      final translator = _direction == Direction.japaneseToEnglish
          ? _jaToEnTranslator!
          : _enToJaTranslator!;

      final translated = await translator.translateText(text);
      _translatedText = translated;

      // Save to history
      _history.insert(
        0,
        TranslationEntry(
          original: text,
          translated: translated,
          direction: _direction,
          timestamp: DateTime.now(),
        ),
      );

      notifyListeners();

      if (speak) {
        await _speakTranslation(translated);
      } else {
        _setAppState(AppState.idle);
        _setStatus('Done — tap Listen or hold Speak');
      }
    } catch (e) {
      debugPrint('Translation error: $e');
      _translatedText = 'Translation failed. Check internet for first-time model download.';
      _setAppState(AppState.error);
      _setStatus('Translation error');
      notifyListeners();
      await Future.delayed(const Duration(seconds: 2));
      _setAppState(AppState.idle);
      _setStatus('Ready');
    }

    notifyListeners();
  }

  Future<void> _speakTranslation(String text) async {
    _setAppState(AppState.speaking);

    // Set TTS language based on what we're speaking OUT
    // In speak mode: direction JA→EN means we heard Japanese, output English for them
    //                direction EN→JA means we heard English, output Japanese for them
    final ttsLang = _direction == Direction.japaneseToEnglish ? 'en-US' : 'ja-JP';
    await _tts.setLanguage(ttsLang);

    _setStatus('Speaking in ${outputLanguageLabel}...');
    notifyListeners();

    await _tts.speak(text);
    // Completion handler will set idle
    await WakelockPlus.disable();
  }

  // ─── DIRECTION TOGGLE ─────────────────────────────────────────────────────

  Future<void> toggleDirection() async {
    if (_appState == AppState.listening || _appState == AppState.speaking) return;

    _direction = _direction == Direction.japaneseToEnglish
        ? Direction.englishToJapanese
        : Direction.japaneseToEnglish;

    _liveText = '';
    _translatedText = '';
    _setStatus('Ready — ${inputLanguageLabel} → ${outputLanguageLabel}');

    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('direction', _direction.index);

    notifyListeners();
  }

  // ─── MANUAL TRANSLATE (type input) ───────────────────────────────────────

  Future<void> translateText(String text) async {
    if (text.trim().isEmpty) return;
    _liveText = text;
    notifyListeners();
    await _translateAndSpeak(text, speak: false);
  }

  // ─── REPLAY TTS ──────────────────────────────────────────────────────────

  Future<void> replayLastTranslation() async {
    if (_translatedText.isEmpty) return;
    await _speakTranslation(_translatedText);
  }

  Future<void> stopSpeakingNow() async {
    await _tts.stop();
    _setAppState(AppState.idle);
    _setStatus('Ready');
    notifyListeners();
  }

  // ─── CLEAR ───────────────────────────────────────────────────────────────

  void clearCurrent() {
    _liveText = '';
    _translatedText = '';
    _setStatus('Ready');
    notifyListeners();
  }

  void clearHistory() {
    _history.clear();
    notifyListeners();
  }

  // ─── HELPERS ─────────────────────────────────────────────────────────────

  void _setAppState(AppState state) {
    _appState = state;
    notifyListeners();
  }

  void _setMode(TranslationMode mode) {
    _mode = mode;
    notifyListeners();
  }

  void _setStatus(String msg) {
    _statusMessage = msg;
    notifyListeners();
  }

  @override
  void dispose() {
    _stt.stop();
    _tts.stop();
    _jaToEnTranslator?.close();
    _enToJaTranslator?.close();
    WakelockPlus.disable();
    super.dispose();
  }
}
