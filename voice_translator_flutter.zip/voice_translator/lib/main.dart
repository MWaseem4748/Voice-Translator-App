import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'services/translator_service.dart';
import 'screens/home_screen.dart';
import 'screens/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Force portrait mode for better UX during calls
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);

  // Immersive status bar
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  runApp(
    ChangeNotifierProvider(
      create: (_) => TranslatorService(),
      child: const VoiceTranslatorApp(),
    ),
  );
}

class VoiceTranslatorApp extends StatelessWidget {
  const VoiceTranslatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '日英 Translator',
      debugShowCheckedModeBanner: false,
      theme: _buildTheme(),
      initialRoute: '/splash',
      routes: {
        '/splash': (_) => const SplashScreen(),
        '/home': (_) => const HomeScreen(),
      },
    );
  }

  ThemeData _buildTheme() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: ColorScheme.dark(
        primary: const Color(0xFFE8426F),       // Torii red
        secondary: const Color(0xFF4ECDC4),      // Teal accent
        tertiary: const Color(0xFFFFD93D),       // Gold
        surface: const Color(0xFF0D0D1A),        // Deep night
        surfaceContainerHighest: const Color(0xFF1A1A2E),  // Card dark
        onSurface: const Color(0xFFF0EAD6),      // Warm white
        outline: const Color(0xFF2A2A45),
      ),
      scaffoldBackgroundColor: const Color(0xFF0D0D1A),
      fontFamily: 'Roboto',
    );
  }
}
