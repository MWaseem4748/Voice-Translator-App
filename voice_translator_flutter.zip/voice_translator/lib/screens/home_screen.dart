import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../services/translator_service.dart';
import '../widgets/wave_painter.dart';
import '../widgets/translation_card.dart';
import '../widgets/history_sheet.dart';
import '../widgets/type_input_sheet.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const _HomeView();
  }
}

class _HomeView extends StatefulWidget {
  const _HomeView();

  @override
  State<_HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<_HomeView> with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _waveController;
  bool _speakButtonHeld = false;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);

    _waveController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _waveController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final service = context.watch<TranslatorService>();
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: cs.surface,
      body: SafeArea(
        child: Column(
          children: [
            _buildTopBar(context, service, cs),
            _buildDirectionBanner(context, service, cs),
            const SizedBox(height: 8),
            Expanded(
              child: _buildTranslationArea(context, service, cs),
            ),
            _buildStatusBar(service, cs),
            _buildControlButtons(context, service, cs),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // ─── TOP BAR ─────────────────────────────────────────────────────────────

  Widget _buildTopBar(BuildContext context, TranslatorService service, ColorScheme cs) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(
        children: [
          Text(
            '🌸',
            style: const TextStyle(fontSize: 22),
          ),
          const SizedBox(width: 10),
          Text(
            '日英 Translator',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: cs.onSurface,
              letterSpacing: 1,
            ),
          ),
          const Spacer(),
          // Type manually button
          IconButton(
            onPressed: () => _showTypeInput(context, service),
            icon: const Icon(Icons.keyboard_alt_outlined),
            color: cs.onSurface.withOpacity(0.6),
            tooltip: 'Type to translate',
          ),
          // History
          IconButton(
            onPressed: () => _showHistory(context, service),
            icon: const Icon(Icons.history_rounded),
            color: cs.onSurface.withOpacity(0.6),
            tooltip: 'Translation history',
          ),
        ],
      ),
    );
  }

  // ─── DIRECTION BANNER ────────────────────────────────────────────────────

  Widget _buildDirectionBanner(
      BuildContext context, TranslatorService service, ColorScheme cs) {
    final active = service.appState != AppState.listening &&
        service.appState != AppState.speaking;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: GestureDetector(
        onTap: active ? () => service.toggleDirection() : null,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          decoration: BoxDecoration(
            color: cs.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: cs.outline,
              width: 1,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _langChip(
                  service.inputLanguageLabel,
                  service.direction == Direction.japaneseToEnglish
                      ? '🇯🇵'
                      : '🇺🇸',
                  cs,
                  isActive: true),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: AnimatedRotation(
                  turns: service.direction == Direction.japaneseToEnglish ? 0 : 0.5,
                  duration: const Duration(milliseconds: 300),
                  child: Icon(
                    Icons.swap_horiz_rounded,
                    color: active ? cs.primary : cs.outline,
                    size: 28,
                  ),
                ),
              ),
              _langChip(
                  service.outputLanguageLabel,
                  service.direction == Direction.japaneseToEnglish
                      ? '🇺🇸'
                      : '🇯🇵',
                  cs,
                  isActive: false),
              if (active) ...[
                const SizedBox(width: 12),
                Icon(Icons.touch_app_outlined,
                    size: 14, color: cs.onSurface.withOpacity(0.35)),
              ]
            ],
          ),
        ),
      ),
    );
  }

  Widget _langChip(String label, String flag, ColorScheme cs,
      {required bool isActive}) {
    return Column(
      children: [
        Text(flag, style: const TextStyle(fontSize: 24)),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
            color: isActive
                ? cs.onSurface
                : cs.onSurface.withOpacity(0.6),
          ),
        ),
      ],
    );
  }

  // ─── TRANSLATION AREA ────────────────────────────────────────────────────

  Widget _buildTranslationArea(
      BuildContext context, TranslatorService service, ColorScheme cs) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Column(
        children: [
          // Original / Live text card
          Expanded(
            child: TranslationCard(
              label: service.inputLanguageLabel,
              text: service.liveText,
              isLive: service.appState == AppState.listening,
              emptyHint: service.appState == AppState.listening
                  ? 'Listening...'
                  : 'Original text appears here',
              color: cs.surfaceContainerHighest,
              textColor: cs.onSurface,
              accentColor: cs.secondary,
              showWave: service.appState == AppState.listening,
              waveController: _waveController,
            ),
          ),
          const SizedBox(height: 10),
          // Translated card
          Expanded(
            child: TranslationCard(
              label: service.outputLanguageLabel,
              text: service.translatedText,
              isLive: false,
              emptyHint: service.appState == AppState.translating
                  ? 'Translating...'
                  : 'Translation appears here',
              color: cs.surfaceContainerHighest,
              textColor: cs.primary,
              accentColor: cs.primary,
              showWave: service.appState == AppState.translating,
              waveController: _waveController,
              trailingWidget: service.translatedText.isNotEmpty
                  ? Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.copy_rounded,
                              size: 18, color: cs.onSurface.withOpacity(0.5)),
                          onPressed: () {
                            Clipboard.setData(
                                ClipboardData(text: service.translatedText));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text('Copied to clipboard'),
                                  duration: Duration(seconds: 1)),
                            );
                          },
                        ),
                        IconButton(
                          icon: service.appState == AppState.speaking
                              ? Icon(Icons.stop_circle_outlined,
                                  size: 20, color: cs.primary)
                              : Icon(Icons.volume_up_rounded,
                                  size: 20, color: cs.primary),
                          onPressed: service.appState == AppState.speaking
                              ? () => service.stopSpeakingNow()
                              : () => service.replayLastTranslation(),
                        ),
                      ],
                    )
                  : null,
            ),
          ),
        ],
      ),
    );
  }

  // ─── STATUS BAR ──────────────────────────────────────────────────────────

  Widget _buildStatusBar(TranslatorService service, ColorScheme cs) {
    Color statusColor;
    IconData statusIcon;

    switch (service.appState) {
      case AppState.listening:
        statusColor = cs.secondary;
        statusIcon = Icons.mic_rounded;
        break;
      case AppState.translating:
        statusColor = cs.tertiary;
        statusIcon = Icons.translate_rounded;
        break;
      case AppState.speaking:
        statusColor = cs.primary;
        statusIcon = Icons.volume_up_rounded;
        break;
      case AppState.error:
        statusColor = cs.error;
        statusIcon = Icons.warning_amber_rounded;
        break;
      default:
        statusColor = cs.onSurface.withOpacity(0.4);
        statusIcon = Icons.radio_button_unchecked_rounded;
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulseController,
            builder: (_, __) => Opacity(
              opacity: service.appState == AppState.listening
                  ? 0.4 + _pulseController.value * 0.6
                  : 1.0,
              child: Icon(statusIcon, color: statusColor, size: 16),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              service.statusMessage,
              style: TextStyle(fontSize: 12, color: statusColor),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          if (service.liveText.isNotEmpty || service.translatedText.isNotEmpty)
            GestureDetector(
              onTap: () => service.clearCurrent(),
              child: Icon(Icons.clear_rounded,
                  size: 16, color: cs.onSurface.withOpacity(0.3)),
            ),
        ],
      ),
    );
  }

  // ─── CONTROL BUTTONS ─────────────────────────────────────────────────────

  Widget _buildControlButtons(
      BuildContext context, TranslatorService service, ColorScheme cs) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 0),
      child: Row(
        children: [
          // LISTEN button (tap to toggle)
          Expanded(
            child: _ListenButton(service: service, cs: cs),
          ),
          const SizedBox(width: 16),
          // SPEAK button (hold)
          Expanded(
            child: _SpeakButton(service: service, cs: cs),
          ),
        ],
      ),
    );
  }

  void _showHistory(BuildContext context, TranslatorService service) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => ChangeNotifierProvider.value(
        value: service,
        child: const HistorySheet(),
      ),
    );
  }

  void _showTypeInput(BuildContext context, TranslatorService service) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => ChangeNotifierProvider.value(
        value: service,
        child: const TypeInputSheet(),
      ),
    );
  }
}

// ─── LISTEN BUTTON ─────────────────────────────────────────────────────────

class _ListenButton extends StatelessWidget {
  final TranslatorService service;
  final ColorScheme cs;

  const _ListenButton({required this.service, required this.cs});

  @override
  Widget build(BuildContext context) {
    final isListeningInListenMode = service.isListening &&
        service.mode == TranslationMode.listenMode;
    final canPress = service.appState == AppState.idle ||
        isListeningInListenMode;

    return GestureDetector(
      onTap: canPress
          ? () => isListeningInListenMode
              ? service.stopListening()
              : service.startListening()
          : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 80,
        decoration: BoxDecoration(
          color: isListeningInListenMode
              ? cs.secondary
              : cs.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isListeningInListenMode
                ? cs.secondary
                : cs.outline,
            width: 1.5,
          ),
          boxShadow: isListeningInListenMode
              ? [BoxShadow(color: cs.secondary.withOpacity(0.4), blurRadius: 20, spreadRadius: 2)]
              : [],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              isListeningInListenMode ? Icons.stop_rounded : Icons.hearing_rounded,
              color: isListeningInListenMode ? Colors.white : cs.secondary,
              size: 28,
            ),
            const SizedBox(height: 4),
            Text(
              isListeningInListenMode ? 'Stop' : 'Listen',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
                color: isListeningInListenMode
                    ? Colors.white
                    : cs.onSurface.withOpacity(0.8),
              ),
            ),
            Text(
              'Their voice',
              style: TextStyle(
                fontSize: 10,
                color: isListeningInListenMode
                    ? Colors.white70
                    : cs.onSurface.withOpacity(0.4),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── SPEAK BUTTON ──────────────────────────────────────────────────────────

class _SpeakButton extends StatefulWidget {
  final TranslatorService service;
  final ColorScheme cs;

  const _SpeakButton({required this.service, required this.cs});

  @override
  State<_SpeakButton> createState() => _SpeakButtonState();
}

class _SpeakButtonState extends State<_SpeakButton> {
  bool _held = false;

  @override
  Widget build(BuildContext context) {
    final cs = widget.cs;
    final service = widget.service;
    final isListeningInSpeakMode = service.isListening &&
        service.mode == TranslationMode.speakMode;
    final active = _held || isListeningInSpeakMode;

    return GestureDetector(
      onLongPressStart: (_) async {
        if (service.appState != AppState.idle) return;
        setState(() => _held = true);
        HapticFeedback.mediumImpact();
        await service.startSpeaking();
      },
      onLongPressEnd: (_) async {
        setState(() => _held = false);
        HapticFeedback.lightImpact();
        await service.stopSpeaking();
      },
      onTap: () {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Hold this button while you speak'),
            duration: Duration(seconds: 2),
          ),
        );
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        height: 80,
        decoration: BoxDecoration(
          color: active ? cs.primary : cs.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: active ? cs.primary : cs.outline,
            width: 1.5,
          ),
          boxShadow: active
              ? [BoxShadow(color: cs.primary.withOpacity(0.5), blurRadius: 24, spreadRadius: 4)]
              : [],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              active ? Icons.mic_rounded : Icons.mic_none_rounded,
              color: active ? Colors.white : cs.primary,
              size: 28,
            ),
            const SizedBox(height: 4),
            Text(
              active ? 'Release' : 'Speak',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.bold,
                color: active ? Colors.white : cs.onSurface.withOpacity(0.8),
              ),
            ),
            Text(
              'Hold to talk',
              style: TextStyle(
                fontSize: 10,
                color: active ? Colors.white70 : cs.onSurface.withOpacity(0.4),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
