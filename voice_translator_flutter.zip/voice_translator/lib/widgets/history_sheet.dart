import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/translator_service.dart';

class HistorySheet extends StatelessWidget {
  const HistorySheet({super.key});

  @override
  Widget build(BuildContext context) {
    final service = context.watch<TranslatorService>();
    final cs = Theme.of(context).colorScheme;

    return DraggableScrollableSheet(
      initialChildSize: 0.6,
      minChildSize: 0.3,
      maxChildSize: 0.92,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: cs.surfaceContainerHighest,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            children: [
              const SizedBox(height: 12),
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: cs.outline,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Text(
                      'History',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: cs.onSurface,
                      ),
                    ),
                    const Spacer(),
                    if (service.history.isNotEmpty)
                      TextButton(
                        onPressed: () {
                          service.clearHistory();
                          Navigator.pop(context);
                        },
                        child: Text('Clear all',
                            style: TextStyle(color: cs.error)),
                      ),
                  ],
                ),
              ),
              const Divider(),
              Expanded(
                child: service.history.isEmpty
                    ? Center(
                        child: Text(
                          'No translations yet',
                          style: TextStyle(
                            color: cs.onSurface.withOpacity(0.4),
                            fontStyle: FontStyle.italic,
                          ),
                        ),
                      )
                    : ListView.separated(
                        controller: scrollController,
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                        itemCount: service.history.length,
                        separatorBuilder: (_, __) =>
                            const SizedBox(height: 10),
                        itemBuilder: (context, i) {
                          final entry = service.history[i];
                          return _HistoryItem(entry: entry, cs: cs);
                        },
                      ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _HistoryItem extends StatelessWidget {
  final TranslationEntry entry;
  final ColorScheme cs;

  const _HistoryItem({required this.entry, required this.cs});

  @override
  Widget build(BuildContext context) {
    final dirLabel = entry.direction == Direction.japaneseToEnglish
        ? '🇯🇵 → 🇺🇸'
        : '🇺🇸 → 🇯🇵';

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cs.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: cs.outline.withOpacity(0.5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(dirLabel, style: const TextStyle(fontSize: 12)),
              const Spacer(),
              Text(
                _formatTime(entry.timestamp),
                style: TextStyle(
                  fontSize: 11,
                  color: cs.onSurface.withOpacity(0.4),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            entry.original,
            style: TextStyle(
              fontSize: 13,
              color: cs.onSurface.withOpacity(0.7),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            entry.translated,
            style: TextStyle(
              fontSize: 14,
              color: cs.primary,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  String _formatTime(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 1) return 'just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${dt.day}/${dt.month}';
  }
}
