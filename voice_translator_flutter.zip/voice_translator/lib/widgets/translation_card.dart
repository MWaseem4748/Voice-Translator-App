import 'package:flutter/material.dart';
import 'wave_painter.dart';

class TranslationCard extends StatelessWidget {
  final String label;
  final String text;
  final bool isLive;
  final String emptyHint;
  final Color color;
  final Color textColor;
  final Color accentColor;
  final bool showWave;
  final AnimationController waveController;
  final Widget? trailingWidget;

  const TranslationCard({
    super.key,
    required this.label,
    required this.text,
    required this.isLive,
    required this.emptyHint,
    required this.color,
    required this.textColor,
    required this.accentColor,
    required this.showWave,
    required this.waveController,
    this.trailingWidget,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isLive ? accentColor.withOpacity(0.5) : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: accentColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(
                  label,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: accentColor,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              const Spacer(),
              if (trailingWidget != null) trailingWidget!,
            ],
          ),
          const SizedBox(height: 8),

          if (showWave && text.isEmpty)
            AnimatedWave(
              controller: waveController,
              color: accentColor,
              height: 28,
            )
          else if (text.isEmpty)
            Text(
              emptyHint,
              style: TextStyle(
                fontSize: 14,
                color: accentColor.withOpacity(0.3),
                fontStyle: FontStyle.italic,
              ),
            )
          else
            Expanded(
              child: SingleChildScrollView(
                child: Text(
                  text,
                  style: TextStyle(
                    fontSize: text.length > 100 ? 15 : 18,
                    color: textColor,
                    height: 1.5,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
