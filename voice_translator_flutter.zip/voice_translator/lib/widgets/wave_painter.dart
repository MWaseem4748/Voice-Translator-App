import 'dart:math';
import 'package:flutter/material.dart';

class WavePainter extends CustomPainter {
  final double progress;
  final Color color;
  final int waveCount;

  WavePainter({
    required this.progress,
    required this.color,
    this.waveCount = 3,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color.withOpacity(0.6)
      ..strokeWidth = 2.0
      ..style = PaintingStyle.stroke;

    for (int i = 0; i < waveCount; i++) {
      final path = Path();
      final offset = i * (2 * pi / waveCount);
      final amplitude = 8.0 - i * 2.0;
      final yCenter = size.height / 2;

      path.moveTo(0, yCenter);

      for (double x = 0; x <= size.width; x++) {
        final y = yCenter +
            amplitude *
                sin((x / size.width * 2 * pi * 2) +
                    (progress * 2 * pi) +
                    offset);
        path.lineTo(x, y);
      }

      canvas.drawPath(path, paint..color = color.withOpacity(0.4 - i * 0.1));
    }
  }

  @override
  bool shouldRepaint(WavePainter oldDelegate) =>
      oldDelegate.progress != progress;
}

class AnimatedWave extends StatelessWidget {
  final AnimationController controller;
  final Color color;
  final double height;

  const AnimatedWave({
    super.key,
    required this.controller,
    required this.color,
    this.height = 32,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      child: AnimatedBuilder(
        animation: controller,
        builder: (_, __) => CustomPaint(
          painter: WavePainter(
            progress: controller.value,
            color: color,
          ),
          child: const SizedBox.expand(),
        ),
      ),
    );
  }
}
